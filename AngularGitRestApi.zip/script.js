
var firstcontroller= function($scope, $http){
  
  
  var promise= $http.get("https://api.github.com/users/odetocode");
  promise.then(function(response){
    
    $scope.user=response.data;
    
    
  });
  
};